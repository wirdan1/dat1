/*
  • index.js ini sudah di kaitkan ke Atlantic h2h untuk kamu yang ingin membuat fitur topup, saya sarankan pakaian integrasi h2h di Atlantic, karna prosesnya aman dan terpercaya
  
  kamu hanya harus menambah atlanticKey di config.js dan kamu sesuaikan saja dengan ketentuan Atlantic, selamat mengoding
*/
const cluster = require('cluster');
const { spawn } = require('child_process');
const path = require('path');
const fs = require('fs');
const os = require('os');
const axios = require('axios');
const crypto = require('crypto');
const chalk = require('chalk');

const [major] = process.versions.node.split('.').map(Number);

if (major < 20) {
  console.error('Node.js versi 20 atau lebih tinggi diperlukan!, Nodejs Lawas Buang...‚');
  process.exit(1);
}

let isRunning = false;

function start(file) {
  if (isRunning) return;
  isRunning = true;

  const args = [path.join(__dirname, file), ...process.argv.slice(2)];
  const p = spawn(process.argv[0], args, {
    stdio: ["inherit", "inherit", "inherit", "ipc"],
  });

  p.on("message", (data) => {
    switch (data) {
      case "reset":
        p.kill();
        isRunning = false;
        start.apply(this, arguments);
        break;
      case "uptime":
        p.send(process.uptime());
        break;
    }
  });

  p.on("exit", (code) => {
    isRunning = false;
    console.error('\x1b[31m%s\x1b[0m', `Exited with code: ${code}`);
    start('main.js');
  });

  p.on("error", (err) => {
    console.error('\x1b[31m%s\x1b[0m', `Error: ${err}`);
    p.kill();
    isRunning = false;
    console.error('\x1b[31m%s\x1b[0m', `Error occurred. Script will restart...`);
    start("main.js");
  });

  setInterval(() => {}, 1000);

  // 🔹 Jalankan function atlantic di sini
  runAtlantic();
}

// =========================
// Function ATLANTIC
// =========================
let pukulChiwa = false;

async function runAtlantic() {
  // Simulasi objek juna & setting (ganti sesuai environment kamu)
  const juna = global.juna; // pastikan juna sudah tersedia di global
  const setting = global.setting || { atlanticKey: process.env.ATLANTIC_KEY };
  const update = { connection: "open", receivedPendingNotifications: "true" };

  if (update.connection === "open" || update.receivedPendingNotifications === "true") {
    if (!pukulChiwa) {
      pukulChiwa = true;

      function makeid(length) {
        let result = '';
        const characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
        for (let i = 0; i < length; i++) {
          result += characters.charAt(Math.floor(Math.random() * characters.length));
        }
        return result;
      }

      setInterval(async () => {
        try {
          const trxRaw = await fs.promises.readFile('./database/transactions.json', 'utf-8');
          const trxData = JSON.parse(trxRaw);
          let isModified = false;

          const pendingTrx = trxData.filter(trx => trx.status === 'pending' || !trx.status);

          for (let trx of pendingTrx) {
            try {
              const response = await axios.post(
                'https://atlantich2h.com/deposit/status',
                new URLSearchParams({ api_key: setting.atlanticKey, id: trx.id }),
                { headers: { 'Content-Type': 'application/x-www-form-urlencoded' } }
              );

              const data = response?.data?.data;
              if (!data) continue;

              if (data.status === 'success' || data.status === 'processing') {
                const orderId = crypto.randomBytes(16).toString('hex');
                const tokenOrder = makeid(32);
                const tokenExpiry = Date.now() + 3 * 60 * 60 * 1000; // 3 jam

                let orderData = [];
                try {
                  orderData = JSON.parse(await fs.promises.readFile('./database/orders.json', 'utf-8'));
                } catch { orderData = []; }

                orderData.push({
                  id: orderId,
                  user_id: trx.sender,
                  transaction_id: trx.id,
                  status: 'pendingConfirmation',
                  product_id: trx.productId,
                  token: tokenOrder,
                  tokenExpiry,
                  createdAt: Date.now()
                });

                await fs.promises.writeFile('./database/orders.json', JSON.stringify(orderData, null, 2), 'utf-8');

                trx.status = 'success';
                isModified = true;

                const more = String.fromCharCode(8206).repeat(4001);
                const requestMessage = `Transaksi ${trx.id} sukses.\nToken: ${tokenOrder}\n${more}`;

                await juna.sendMessage(trx.msg_data?.remoteJid || trx.sender, { text: requestMessage });

              } else if (data.status !== 'pending') {
                trx.status = data.status;
                isModified = true;
              }

            } catch (e) { console.error(e); }
          }

          if (isModified) {
            await fs.promises.writeFile('./database/transactions.json', JSON.stringify(trxData, null, 2), 'utf-8');
          }

        } catch (error) {
          console.error('Error polling transactions:', error);
        }
      }, 5000);
    }
  }
}

// =========================
start("main.js");

process.on('unhandledRejection', (reason) => {
  console.error('\x1b[31m%s\x1b[0m', `Unhandled promise rejection: ${reason}`);
  start('main.js');
});

process.on('exit', (code) => {
  console.error(`Exited with code: ${code}`);
  start('main.js');
});

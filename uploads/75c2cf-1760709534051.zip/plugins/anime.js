import axios from "axios"
import * as cheerio from "cheerio"

const handler = async (m, { conn }) => {
  try {
    m.reply("> Mengambil data anime yang akan rilis...")

    const { data } = await axios.get("https://animecountdown.com/premieres?allow")
    const $ = cheerio.load(data)
    const now = new Date()
    const items = []

    $("a.countdown-content-trending-item").each((i, el) => {
      const poster = $(el).attr("data-poster")
      const hotPercentage = $(el).attr("data-hot-percentage")
      const timeStr = $(el).find(".countdown").attr("data-time")
      const title = $(el).find(".countdown-content-trending-item-title").text().trim()
      const desc = $(el).find(".countdown-content-trending-item-desc").text().trim()

      const absSeconds = Math.abs(parseInt(timeStr, 10))
      const countdownDate = new Date(now.getTime() + absSeconds * 1000)
      const days = Math.floor(absSeconds / (24 * 60 * 60))
      const hours = Math.floor((absSeconds % (24 * 60 * 60)) / (60 * 60))
      const minutes = Math.floor((absSeconds % (60 * 60)) / 60)
      const seconds = absSeconds % 60

      items.push({
        href: `https://simkl.com${$(el).attr("href")}`,
        title,
        desc,
        poster: `https:${poster}`,
        hotPercentage: parseInt(hotPercentage, 10),
        date: countdownDate.toISOString(),
        remaining: `${days} hari ${hours} jam ${minutes} menit ${seconds} detik`,
      })
    })

    if (!items.length) return m.reply("> Tidak ditemukan data anime terbaru.")

    const textResult = items
      .slice(0, 10)
      .map(
        (x, i) =>
          [
            `> *${i + 1}. ${x.title}*`,
            `> Rilis: ${new Date(x.date).toLocaleString("id-ID")}`,
            `> Popularitas: ${x.hotPercentage}%`,
            `> Waktu tersisa: ${x.remaining}`,
            `> Poster: ${x.poster}`,
            `> Link: ${x.href}`,
            x.desc ? `> ${x.desc}` : "",
          ].join("\n")
      )
      .join("\n\n")

    await conn.sendMessage(
      m.chat,
      { text: `> *Daftar Anime yang Akan Rilis*\n\n${textResult}` },
      { quoted: m }
    )
  } catch (e) {
    console.error(e)
    m.reply(`> Terjadi kesalahan: ${e.message}`)
  }
}

handler.help = ["anime"]
handler.tags = ["anime"]
handler.command = /^anime$/i

export default handler
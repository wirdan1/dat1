const fetch = require('node-fetch');

let deku = async (m, {
    conn,
    usedPrefix,
    command
}) => {
    const neko = new NekoAPI();

    try {
        const result = await neko.get();
        if (!result || !result.buffer) throw "📛 Gagal ambil gambar neko. Coba lagi ya~";

        let cap = `🐱 *Here is your neko!*\n`;
        cap += `\n> Kalau kurang puas... klik tombol [ Next / Lanjut ]~`;

        await conn.sendAliasMessage(m.chat, {
            image: {
                url: result.url
            },
            caption: cap
        }, [{
            alias: "next",
            response: `${usedPrefix + command}`
        }, {
            alias: "lanjut",
            response: `${usedPrefix + command}`
        }], m);

    } catch (err) {
        console.error(err);
        m.reply('🥲 *Oops!* Gagal mengambil gambar dari API neko. Servernya lagi bobo kali.');
    }
};

deku.command = ["neko"];
deku.help = ["neko"];
deku.tags = ["random"];
deku.limit = true;
deku.loading = true;

// 🧩 Class NekoAPI
class NekoAPI {
    api = 'https://api.siputzx.my.id/api/r/neko';

    async get() {
        try {
            const res = await fetch(this.api);
            if (!res.ok) throw new Error(`HTTP ${res.status}`);
            const buffer = await res.buffer();

            return {
                buffer,
                url: this.api // since it's random, we reuse the same URL
            };
        } catch (e) {
            console.error(e);
            return null;
        }
    }
}

module.exports = deku;

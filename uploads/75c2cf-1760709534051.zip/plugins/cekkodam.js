// Plugin: cekkodam.js
// Fungsi: Menentukan khodam random untuk nama yang diberikan (persistent)
// Creator: Danz

const fs = require('fs');
const path = './database/cekkodam.json';

if (!fs.existsSync(path)) fs.writeFileSync(path, JSON.stringify({}));

module.exports = {
    help: ['cekkodam <nama>'],
    tags: ['fun'],
    command: ['cekkodam'],
    limit: true,
    energy: 1,

    code: async (m, { text }) => {
        if (!text) return m.reply("> Kasih Nama Lah Kocak, Lu Mau Cek Kodam Siapa?");

        const daftarKhodam = [
            "Kaleng Cat Avian","Pipa Rucika","Botol Tupperware","Badut Mixue","Sabun GIV",
            "Sandal Swallow","Jarjit","Ijat","Fizi","Mail","Ehsan","Upin","Ipin","Kak Ros",
            "Tok Dalang","Opah","Opet","Alul","Pak Vinsen","Maman Resing","Pak RT","Admin ETI",
            "Bung Towel","Lumpia Basah","Martabak Manis","Baso Tahu","Tahu Gejrot","Dimsum",
            "Seblak Ceker","Telor Gulung","Tahu Aci","Tempe Mendoan","Nasi Kucing","Kue Cubit",
            "Tahu Sumedang","Nasi Uduk","Wedang Ronde","Kerupuk Udang","Cilok","Cilung","Kue Sus",
            "Jasuke","Seblak Makaroni","Sate Padang","Sayur Asem","Kromboloni","Marmut Pink",
            "Belalang Mullet","Kucing Oren","Lintah Terbang","Singa Paddle Pop","Macan Cisewu",
            "Vario Mber","Beat Mber","Supra Geter","Oli Samping","Knalpot Racing","Jus Stroberi",
            "Jus Alpukat","Alpukat Kocok","Es Kopyor","Es Jeruk","Cappucino Cincau","Jasjus Melon",
            "Teajus Apel","Pop ice Mangga","Teajus Gulabatu","Air Selokan","Air Kobokan","TV Tabung",
            "Keran Air","Tutup Panci","Kotak Amal","Tutup Termos","Tutup Botol","Kresek Item",
            "Kepala Casan","Ban Serep","Kursi Lipat","Kursi Goyang","Kulit Pisang","Warung Madura",
            "Gorong-gorong"
        ];

        let db = JSON.parse(fs.readFileSync(path, 'utf-8'));

        let namaKey = text.toLowerCase();
        if (!db[namaKey]) {
            db[namaKey] = daftarKhodam[Math.floor(Math.random() * daftarKhodam.length)];
            fs.writeFileSync(path, JSON.stringify(db, null, 2));
        }

        const caption = `
╭━━━━°「 *Cekkodam* 」°
┃
┊• Nama : ${text}
┃• Khodam : *${db[namaKey]}*
╰═┅═━––––––๑
        `;

        m.reply(caption);
    }
};

import axios from "axios"
import FormData from "form-data"
import fs from "fs"
import { JSDOM } from "jsdom"

async function img2img(buffer, text) {
  try {
    const tmpFile = "./tmp_upload.png"
    fs.writeFileSync(tmpFile, buffer) // simpan buffer ke file sementara

    const form = new FormData()
    form.append("file", fs.createReadStream(tmpFile))
    form.append("text", text)

    const { data } = await axios.post("https://img2img.zone.id/result", form, {
      headers: form.getHeaders(),
      timeout: 20000,
    })

    fs.unlinkSync(tmpFile) // hapus file sementara

    const dom = new JSDOM(data)
    const img = dom.window.document.querySelector("#result")

    if (!img) throw new Error("Tidak ada gambar hasil")
    return img.src
  } catch (err) {
    throw new Error("Upload gagal: " + err.message)
  }
}

const handler = async (m, { conn, text, command }) => {
  if (!m.quoted && !m.msg?.message?.imageMessage && !m.quoted?.message?.imageMessage) {
    return m.reply(`> Kirim / reply gambar dengan caption:\n.${command} prompt teks`)
  }
  if (!text) return m.reply(`> Contoh:\n.${command} ubah jadi karakter anime`)

  try {
    await conn.sendMessage(m.chat, { react: { text: "⏳", key: m.key } })

    const buffer = await (m.quoted ? m.quoted.download() : m.download())
    if (!buffer) throw new Error("Gagal mengunduh gambar dari pesan.")

    const resultUrl = await img2img(buffer, text)

    await conn.sendMessage(
      m.chat,
      {
        image: { url: resultUrl },
        caption: `> ✅ *Hasil img2img:*\n_${text}_`,
      },
      { quoted: m }
    )

    await conn.sendMessage(m.chat, { react: { text: "✅", key: m.key } })
  } catch (err) {
    console.error(err)
    await conn.sendMessage(m.chat, { react: { text: "❌", key: m.key } })
    m.reply(`> Terjadi kesalahan:\n*${err.message}*`)
  }
}

handler.help = ["img2img"]
handler.tags = ["ai", "tools"]
handler.command = /^img2img$/i
handler.limit = 20

export default handler
async function ssweb(url) {
  const h = {
    accept: "*/*",
    "accept-language": "id-ID,id;q=0.9,en-US;q=0.8,en;q=0.7",
    "content-type": "application/json",
    origin: "https://imagy.app",
    priority: "u=1, i",
    referer: "https://imagy.app/",
    "sec-ch-ua": '"Not)A;Brand";v="8", "Chromium";v="138", "Google Chrome";v="138"',
    "sec-ch-ua-mobile": "?0",
    "sec-ch-ua-platform": '"Windows"',
    "sec-fetch-dest": "empty",
    "sec-fetch-mode": "cors",
    "sec-fetch-site": "same-site",
    "user-agent":
      "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36",
  }

  const data = {
    url: url,
    browserWidth: 1280,
    browserHeight: 720,
    fullPage: false,
    deviceScaleFactor: 1,
    format: "png",
  }

  try {
    const res = await fetch("https://gcp.imagy.app/screenshot/createscreenshot", {
      method: "POST",
      headers: h,
      body: JSON.stringify(data),
    })

    if (!res.ok) throw new Error(`HTTP ${res.status} ${res.statusText}`)
    const json = await res.json()

    return {
      id: json.id,
      fileUrl: json.fileUrl,
      success: true,
    }
  } catch (e) {
    return {
      success: false,
      error: e.message,
    }
  }
}

let handler = async (m, { conn, text }) => {
  if (!text)
    return m.reply(
      `⚠️ Masukkan URL yang ingin di-screenshot!\n\nContoh:\n.ssweb2 https://example.com`
    )

  await m.reply("_> Proses screenshot..._")

  const result = await ssweb(text)
  if (!result.success)
    return m.reply(`❌ Gagal mengambil screenshot:\n${result.error}`)

  await conn.sendFile(
    m.chat,
    result.fileUrl,
    "screenshot.png",
    `✅ Screenshot berhasil!\n\nURL: ${text}`,
    m
  )
}

handler.help = ["ssweb2 <url>"]
handler.tags = ["tools"]
handler.command = /^ssweb2$/i

export default handler

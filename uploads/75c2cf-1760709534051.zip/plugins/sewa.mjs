// ===== SewaBotService =====
class SewaBotService {
  constructor(bot) {
    this.bot = bot; // instance Baileys
  }

  // Konversi durasi ke milidetik
  parseDuration(duration) {
    const regex = /^(\d+)(m|h|d|w|mo|y)$/i;
    const match = duration.match(regex);
    if (!match) throw new Error("Format durasi invalid! Contoh: 1m, 2h, 3d, 1w, 1mo, 1y");

    const [_, valueStr, unit] = match;
    const value = parseInt(valueStr);

    switch (unit.toLowerCase()) {
      case "m": return value * 60 * 1000;              // menit
      case "h": return value * 60 * 60 * 1000;         // jam
      case "d": return value * 24 * 60 * 60 * 1000;    // hari
      case "w": return value * 7 * 24 * 60 * 60 * 1000; // minggu
      case "mo": return value * 30 * 24 * 60 * 60 * 1000; // bulan aprox
      case "y": return value * 365 * 24 * 60 * 60 * 1000; // tahun aprox
      default: throw new Error("Unit durasi tidak dikenali");
    }
  }

  async joinGroup(groupLink, duration) {
    const timeMs = this.parseDuration(duration);

    // Ambil invite code bersih dari link
    const inviteCode = groupLink.split("/").pop().split("?")[0];
    if (!inviteCode) throw new Error("Link grup tidak valid");

    // Join grup
    const groupId = await this.bot.groupAcceptInvite(inviteCode);

    // Kirim pesan masuk
    await this.bot.sendMessage(groupId, {
      text: `Halo! Saya akan berada di grup ini selama ${duration}.`
    });

    // Set timeout keluar otomatis
    setTimeout(async () => {
      await this.bot.sendMessage(groupId, { text: "Waktu sewabot selesai. Saya keluar ya!" });
      await this.bot.groupLeave(groupId);
    }, timeMs);

    return { groupId, duration };
  }
}

// ===== Handler Command =====
let handler = async (m, { text, conn }) => {
  try {
    if (!text) {
      return m.reply(
        "Format command:\n" +
        ".sewabot\n" +
        ".sewa <durasi>|<link grup>\n\n" +
        "Contoh:\n.sewa 1h|https://chat.whatsapp.com/XXXX\n" +
        "Satuan durasi: m=menit, h=jam, d=hari, w=minggu, mo=bulan, y=tahun"
      );
    }

    const [duration, groupLink] = text.split("|").map(s => s.trim());
    if (!duration || !groupLink) return m.reply("Format salah. Gunakan: durasi|link grup");

    const service = new SewaBotService(conn); // conn = instance bot WA
    m.reply("Proses join grup...");

    const res = await service.joinGroup(groupLink, duration);
    m.reply(`Berhasil join grup!\nDurasi: ${res.duration}\nGroup ID: ${res.groupId}`);
  } catch (e) {
    console.error(e);
    m.reply("Terjadi kesalahan: " + e.message);
  }
};

handler.command = /^sewa(bot)?$/i;
handler.help = [".sewabot", ".sewa <durasi>|<link grup>"];
handler.tags = ["utility"];

export default handler;
import fs from "fs"

const handler = async (m, { conn }) => {
  const q = m.quoted ? m.quoted : m
  const mime = (q.msg || q).mimetype || ""

  if (!/webp/.test(mime))
    return m.reply(`> Balas sebuah sticker dengan caption *.toimg*`)

  try {
    const media = await q.download()
    const path = "./tmp/toimg.png"
    await fs.promises.writeFile(path, media)

    await conn.sendMessage(m.chat, { image: fs.readFileSync(path) }, { quoted: m })
    await fs.promises.unlink(path)
  } catch (err) {
    console.error(err)
    await m.reply("> Gagal mengonversi sticker ke gambar.")
  }
}

handler.help = ["toimg"]
handler.tags = ["tools"]
handler.command = /^(toimg)$/i
handler.limit = 5

export default handler
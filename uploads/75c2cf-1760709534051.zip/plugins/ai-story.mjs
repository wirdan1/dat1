import fetch from "node-fetch"

const handler = async (m, { text, usedPrefix, command }) => {
  if (!text)
    return m.reply(`> Masukkan teks untuk dijadikan cerita.\n*Contoh:* ${usedPrefix + command} A little boy and a cat`)

  const apiKey = "1234Test"
  const baseUrl = "https://responsedh.mycdnpro.com/api/Text/Generate"

  const requestBody = {
    text,
    client: "Hookrest",
    toolName: "_storygenerator",
    mode: "Any genre",
    length: "Short",
    creative: "Medium",
  }

  try {
    const res = await fetch(baseUrl, {
      method: "POST",
      headers: {
        "User-Agent": "Dart/3.8 (dart:io)",
        "Content-Type": "application/json",
        "dhp-api-key": apiKey,
      },
      body: JSON.stringify(requestBody),
    })

    if (!res.ok) throw new Error(`HTTP Error ${res.status}`)

    const data = await res.json()

    if (!data.isSuccess)
      throw new Error(data.errorMessages?.join(", ") || "Gagal menghasilkan cerita.")

    const story = data.response || "Tidak ada hasil dari server."

    await m.reply(`*AI Story Generator*\n> Berdasarkan teks: _${text}_\n\n${story}`)
  } catch (err) {
    console.error(err)
    await m.reply(`> Terjadi kesalahan saat membuat cerita.\n${err.message}`)
  }
}

handler.help = ["story", "aistory"]
handler.tags = ["ai"]
handler.command = /^(story|aistory)$/i
handler.limit = 5

export default handler
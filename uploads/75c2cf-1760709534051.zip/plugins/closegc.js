// ☘️ Thanks To Danz

let moment = require('moment-timezone');
const timeZone = 'Asia/Jakarta';

let handler = async (m, { conn, command, args, isOwner, isAdmin, usedPrefix }) => {
    let chat = global.db.data.chats[m.chat];
    if (!m.isGroup) return m.reply('> Perintah ini hanya untuk grup');
    if (!(isAdmin || isOwner)) return m.reply('> Hanya admin yang bisa menggunakan perintah ini');

    if (command === 'aktif' && args[0] === 'closegc') {
        if (args.length < 2) return m.reply(`> Format salah!\n> Contoh: *${usedPrefix + command} closegc 21|5*`);
        let [closeTime, openTime] = args[1].split('|').map(Number);
        if (isNaN(closeTime) || isNaN(openTime)) return m.reply('> Jam tutup dan buka harus angka');
        chat.autoGc = { closeTime, openTime };
        chat.groupStatus = null;
        m.reply(`> ☘️ Auto close/open grup diaktifkan\n> Tutup: *${closeTime}:00 WIB*\n> Buka: *${openTime}:00 WIB*`);
    } else if (command === 'mati' && args[0] === 'closegc') {
        delete chat.autoGc;
        delete chat.groupStatus;
        m.reply('> ☘️ Auto close/open grup dimatikan');
    }
};

handler.command = /^(aktif|mati)$/i;
handler.help = ['aktif closegc jamTutup|jamBuka', 'mati closegc'];
handler.tags = ['group'];
handler.admin = true;
handler.group = true;

module.exports = handler;

// Fungsi pengecekan otomatis
async function checkGroupsStatus(conn) {
    const currentHour = moment().tz(timeZone).hour();

    for (const chatId of Object.keys(global.db.data.chats)) {
        const chat = global.db.data.chats[chatId];
        if (!chat.autoGc) continue;

        const { closeTime, openTime } = chat.autoGc;

        if (currentHour === closeTime && chat.groupStatus !== 'closed') {
            try {
                await conn.groupSettingUpdate(chatId, 'announcement');
                await conn.sendMessage(chatId, { text: `> ☘️ (OTOMATIS) Grup ditutup\n> Akan dibuka kembali jam *${openTime}:00 WIB*` });
                chat.groupStatus = 'closed';
            } catch (e) {
                console.error(`Error closing group ${chatId}:`, e);
            }
        }

        if (currentHour === openTime && chat.groupStatus !== 'opened') {
            try {
                await conn.groupSettingUpdate(chatId, 'not_announcement');
                await conn.sendMessage(chatId, { text: `> ☘️ (OTOMATIS) Grup dibuka\n> Akan ditutup kembali jam *${closeTime}:00 WIB*` });
                chat.groupStatus = 'opened';
            } catch (e) {
                console.error(`Error opening group ${chatId}:`, e);
            }
        }
    }
}

// Jalankan setiap menit
setInterval(async () => {
    if (global.conn) {
        checkGroupsStatus(global.conn);
    }
}, 60000);

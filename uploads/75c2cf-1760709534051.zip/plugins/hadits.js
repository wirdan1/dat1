// Plugin: hadits.js
// Creator: Danz
// Fungsi: Mengambil hadits random dari API Islami dengan dukungan tombol Next/Lanjut
// Dependensi: node-fetch

const fetch = require('node-fetch');

let handler = async (m, { conn, usedPrefix, command }) => {
    const hadits = new HaditsAPI();

    try {
        const result = await hadits.get();
        if (!result) throw "> Gagal mengambil hadits. Silakan coba lagi.";

        let cap = `> *Sumber:* ${result.sumber}\n`;
        cap += `> *Nomor:* ${result.nomor}\n`;
        cap += `> *Judul:* ${result.judul}\n\n`;
        cap += `${result.teks_arab}\n\n`;
        cap += `> *Terjemahan:*\n${result.terjemahan}\n\n`;
        cap += `> Ketik *next* atau *lanjut* untuk hadits lainnya`;

        await conn.sendAliasMessage(
            m.chat,
            {
                text: cap
            },
            [
                { alias: "next", response: `${usedPrefix + command}` },
                { alias: "lanjut", response: `${usedPrefix + command}` }
            ],
            m
        );

    } catch (err) {
        console.error(err);
        m.reply("> Terjadi kesalahan saat mengambil hadits.");
    }
};

handler.command = ["hadits"];
handler.help = ["hadits"];
handler.tags = ["islami"];
handler.limit = false;

// 🧩 Class HaditsAPI
class HaditsAPI {
    api = 'https://hookrest-api.vercel.app/islami/hadits/random';

    async get() {
        try {
            const res = await fetch(this.api);
            if (!res.ok) throw new Error(`HTTP ${res.status}`);
            const json = await res.json();
            if (!json.status || !json.result) return null;

            return json.result;
        } catch (e) {
            console.error(e);
            return null;
        }
    }
}

module.exports = handler;

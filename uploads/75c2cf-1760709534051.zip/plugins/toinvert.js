const Jimp = require('jimp')

module.exports = {
  help: ['toinvert'],
  tags: ['tools'],
  command: ['toinvert'],
  limit: true,

  code: async (m, { conn }) => {
    const q = m.quoted ? m.quoted : m
    const mime = (q.msg || q).mimetype || ''

    if (!mime.startsWith('image/')) return m.reply('Kirim/quote gambar untuk dibalik warnanya')

    m.reply('Sedang diproses...')
    const media = await q.download()

    try {
      const image = await Jimp.read(media)
      image.invert()
      const buffer = await image.getBufferAsync(Jimp.MIME_JPEG)

      await conn.sendMessage(
        m.chat,
        { image: buffer, caption: 'Gambar sudah dibalik warnanya (invert)' },
        { quoted: m }
      )
    } catch (e) {
      m.reply('Terjadi kesalahan: ' + e.message)
    }
  }
}

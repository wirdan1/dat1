const fetch = require("node-fetch")
const yts = require("yt-search")
const { toWhatsAppVoice } = require("../lib/audioConverter")

const handler = async (m, { conn, text, command }) => {
  if (!text) return m.reply(`> Contoh penggunaan:\n> .${command} menepi`)

  try {
    // Reaksi proses
    await conn.sendMessage(m.chat, { react: { text: "⏳", key: m.key } })

    // Cari video dari yt-search
    const search = await yts(text)
    const vid = search.videos[0]
    if (!vid) {
      await conn.sendMessage(m.chat, { react: { text: "❌", key: m.key } })
      return m.reply("> Tidak ditemukan hasil video dari pencarian.")
    }

    // Ambil audio dari API baru
    const apiUrl = `https://izumiiiiiiii.dpdns.org/downloader/youtube?url=${encodeURIComponent(vid.url)}&format=mp3`
    const res = await fetch(apiUrl)
    if (!res.ok) throw new Error("Gagal menghubungi API.")

    const json = await res.json()
    if (!json.status || !json.result || !json.result.download) {
      throw new Error("Gagal mengambil audio dari API.")
    }

    const { title, download, metadata } = json.result
    const duration = metadata?.duration || "Tidak diketahui"
    const quality = "128" // API tidak mengirim bitrate, jadi default 128kbps

    try {
      // Fetch audio buffer from download URL
      const audioResponse = await fetch(download)
      const audioBuffer = await audioResponse.buffer()

      // Convert to WhatsApp voice note with waveform
      const { audio, waveform } = await toWhatsAppVoice(audioBuffer)

      // Kirim audio dengan stable conversion
      await conn.sendMessage(
        m.chat,
        {
          audio: audio,
          waveform: waveform,
          mimetype: "audio/ogg; codecs=opus",
          fileName: `${title}.ogg`,
          ptt: false,
        },
        { quoted: m },
      )
    } catch (conversionError) {
      console.error("Stable conversion failed, using fallback:", conversionError)
      // Fallback to original method
      await conn.sendMessage(
        m.chat,
        {
          audio: { url: download },
          mimetype: "audio/mpeg",
          fileName: `${title}.mp3`,
          ptt: false,
        },
        { quoted: m },
      )
    }

    // Kirim info
    await m.reply(
      ["> Hasil:", `> *Judul:* ${title}`, `> *Durasi:* ${duration}`, `> *Kualitas:* ${quality}kbps`].join("\n"),
    )

    // Reaksi sukses
    await conn.sendMessage(m.chat, { react: { text: "✅", key: m.key } })
  } catch (err) {
    // Reaksi error
    await conn.sendMessage(m.chat, { react: { text: "❌", key: m.key } })
    m.reply(`> Terjadi kesalahan:\n*${err.message}*`)
  }
}

handler.help = ["play"]
handler.tags = ["downloader"]
handler.command = /^play$/i
handler.energy = 20

module.exports = handler

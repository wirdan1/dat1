import fetch from "node-fetch"
import * as cheerio from "cheerio"

const handler = async (m, { text }) => {
  if (!text) return m.reply("> Gunakan format:\n*ncs <judul>*\nContoh: *ncs alan walker*")

  try {
    const baseUrl = "https://ncs.io"
    const url = `${baseUrl}/music-search?q=${encodeURIComponent(text)}`
    const res = await fetch(url, {
      headers: {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64)"
      }
    })

    const html = await res.text()
    const $ = cheerio.load(html)
    const tracks = []

    $("table.tablesorter tbody tr").each((_, el) => {
      const $row = $(el)
      const $play = $row.find(".player-play")

      const tid = $play.attr("data-tid") || ""
      const title = $play.attr("data-track") || ""
      const artist = $play.attr("data-artistraw") || ""
      const previewUrl = $play.attr("data-url") || ""
      const image = $row.find("td img[alt]").attr("src") || ""
      const releaseDate = $row.find("td:nth-child(6)").text().trim()

      if (tid && title) {
        tracks.push({
          tid,
          title,
          artist,
          previewUrl,
          image,
          releaseDate
        })
      }
    })

    if (!tracks.length) return m.reply("> Tidak ditemukan hasil untuk *" + text + "*")

    const first = tracks[0]
    const caption = [
      `> *NCS Result*`,
      ``,
      `*Judul:* ${first.title}`,
      `*Artis:* ${first.artist}`,
      `*Rilis:* ${first.releaseDate}`,
      ``,
      `*Preview:* ${first.previewUrl || "Tidak tersedia"}`,
      `*Link:* ${baseUrl}/track/${first.tid}`
    ].join("\n")

    await m.reply(caption)
    if (first.image) {
      await m.conn.sendFile(m.chat, first.image, "", caption, m)
    }

  } catch (e) {
    console.error("NCS Plugin Error:", e)
    return m.reply("> Terjadi kesalahan saat mengambil data NCS.")
  }
}

handler.help = ["ncs <judul>"]
handler.tags = ["music"]
handler.command = /^ncs$/i

export default handler
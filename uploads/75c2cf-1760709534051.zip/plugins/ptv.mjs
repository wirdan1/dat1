import fetch from "node-fetch"

const handler = async (m, { text, command, usedPrefix, conn }) => {
  if (!text)
    return m.reply(`> Masukkan kata kunci untuk pencarian.\n*Contoh:* ${usedPrefix + command} dj tiktok`)

  await conn.sendMessage(m.chat, { react: { text: "🔎", key: m.key } })

  try {
    const res = await fetch(`https://apizell.web.id/download/tiktokplay?q=${encodeURIComponent(text)}`)
    const json = await res.json()

    if (!json.status || !json.data || !json.data.length)
      return m.reply("> Video TikTok tidak ditemukan.")

    const video = json.data[0]
    const videoUrl = video.url

    await conn.sendMessage(
      m.chat,
      {
        video: { url: videoUrl },
        ptv: true,
        mimetype: "video/mp4",
        caption: `*TikTok Play*\n> Hasil pencarian: ${text}`,
      },
      { quoted: m }
    )

    await conn.sendMessage(m.chat, { react: { text: "✅", key: m.key } })
  } catch (e) {
    console.error("[PTV ERROR]", e)
    await conn.sendMessage(m.chat, { react: { text: "❌", key: m.key } })
    m.reply("> Terjadi kesalahan saat mengambil video TikTok.")
  }
}

handler.help = ["ptv"]
handler.tags = ["downloader"]
handler.command = /^ptv$/i
handler.limit = 5

export default handler
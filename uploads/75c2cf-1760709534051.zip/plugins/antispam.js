// > Creator: Danz
// > Plugin: antispamgc.js

const MAX_SPAM_COUNT = 3; // batas pesan
const SPAM_INTERVAL = 2000; // jeda pesan (ms)
let spamTracker = {};

let handler = async (m, { text, usedPrefix, command, isAdmin, isOwner }) => {
    let list = `*[ ! ]* Pilihan
Mau pilih yang mana?
on
off

*[ ! ]* Pilihan 2
Mau type mana?
--delete
--kick

Contoh:
${usedPrefix + command} on --kick`;

    let [ena, typeRaw] = text.split(' --');
    let type = typeRaw?.trim()?.toLowerCase();

    if (!ena || !type) return m.reply(list);

    ena = ena.trim().toLowerCase();
    const validTypes = ['delete', 'kick'];

    if (!validTypes.includes(type)) return m.reply('*[ ! ]* Type tidak dikenali.');

    db.data.chats[m.chat] ||= {};
    db.data.chats[m.chat].antispamgc ||= {};

    if (ena === 'on') {
        db.data.chats[m.chat].antispamgc[type] = true;
    } else if (ena === 'off') {
        db.data.chats[m.chat].antispamgc[type] = false;
    }

    m.reply(`*[ ! ]* Fitur *--${type}* sekarang *${ena === 'on' ? 'aktif' : 'nonaktif'}*`);
};

// Deteksi spam sebelum handler utama
handler.before = async (m, { conn, isAdmin, isOwner }) => {
    if (!m.isGroup) return;
    let setting = db.data.chats[m.chat]?.antispamgc;
    if (!setting) return;

    let now = Date.now();
    let sender = m.sender;

    if (!spamTracker[m.chat]) spamTracker[m.chat] = {};
    if (!spamTracker[m.chat][sender]) {
        spamTracker[m.chat][sender] = { count: 1, last: now };
    } else {
        let diff = now - spamTracker[m.chat][sender].last;
        spamTracker[m.chat][sender].last = now;

        if (diff < SPAM_INTERVAL) {
            spamTracker[m.chat][sender].count++;
        } else {
            spamTracker[m.chat][sender].count = 1;
        }

        if (spamTracker[m.chat][sender].count >= MAX_SPAM_COUNT) {
            if (isAdmin || isOwner) {
                await conn.sendMessage(m.chat, { text: '> Anda *admin*, saya mematuhi anda', mentions: [sender] });
            } else {
                if (setting.delete) {
                    await conn.sendMessage(m.chat, { delete: m.key });
                }
                if (setting.kick) {
                    try {
                        await conn.groupParticipantsUpdate(m.chat, [sender], 'remove');
                        await conn.sendMessage(m.chat, { text: `*[ ! ]* @${sender.split('@')[0]} di-kick karena spam`, mentions: [sender] });
                    } catch (e) {
                        console.error('Gagal kick:', e);
                    }
                }
            }
            delete spamTracker[m.chat][sender];
        }
    }
};

handler.help = ['antispamgc'];
handler.tags = ['group'];
handler.command = /^antispamgc$/i;
handler.group = true;
handler.admin = true;
handler.botAdmin = true;

module.exports = handler;

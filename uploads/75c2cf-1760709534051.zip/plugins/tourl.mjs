// plugin/tourl.js (ESM)
import axios from 'axios'
import fs from 'fs'
import FormData from 'form-data'

// Upload ke Catbox
async function catboxUploader(filePath) {
  const form = new FormData()
  form.append('fileToUpload', fs.createReadStream(filePath))
  form.append('reqtype', 'fileupload')

  const res = await axios.post('https://catbox.moe/user/api.php', form, {
    headers: form.getHeaders(),
  })
  return res.data // langsung link
}

export default {
  help: ['tourl'],
  tags: ['tools'],
  command: ['tourl'],
  limit: true,

  code: async (m, { conn }) => {
    const q = m.quoted ? m.quoted : m
    const mime = (q.msg || q).mimetype || ''

    if (!mime) {
      return m.reply('Kirim/quote media dengan caption *.tourl*')
    }

    try {
      m.reply(`> *_proses upload media @${m.sender.split('@')[0]}..._*`, m.chat, { mentions: [m.sender] })

      // download media
      const mediaPath = await conn.downloadAndSaveMediaMessage(q)
      const url = await catboxUploader(mediaPath)
      fs.unlinkSync(mediaPath) // hapus file lokal

      await m.reply(`✅ Media berhasil diupload\n\n🔗 URL: ${url}`)
    } catch (err) {
      console.error('tourl error:', err)
      m.reply('Terjadi kesalahan saat upload: ' + (err.message || err))
    }
  }
}

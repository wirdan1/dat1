// plugin/lyrics.js (ESM)
import fs from 'fs'
import path from 'path'
import axios from 'axios'
import { createCanvas, registerFont } from 'canvas'

// Optional: load font custom kalau ada di ./fonts
try {
  const fontsDir = path.resolve('./fonts')
  if (fs.existsSync(path.join(fontsDir, 'Poppins-Bold.ttf'))) {
    registerFont(path.join(fontsDir, 'Poppins-Bold.ttf'), { family: 'Poppins', weight: '700' })
  }
  if (fs.existsSync(path.join(fontsDir, 'Poppins-Regular.ttf'))) {
    registerFont(path.join(fontsDir, 'Poppins-Regular.ttf'), { family: 'Poppins', weight: '400' })
  }
} catch (err) {
  console.warn('Font load warning:', err.message)
}

function wrapText(ctx, text, maxWidth) {
  const words = text.split(/\s+/)
  const lines = []
  let line = ''
  for (let n = 0; n < words.length; n++) {
    const testLine = line ? (line + ' ' + words[n]) : words[n]
    const metrics = ctx.measureText(testLine)
    if (metrics.width > maxWidth && line) {
      lines.push(line)
      line = words[n]
    } else {
      line = testLine
    }
  }
  if (line) lines.push(line)
  return lines
}

async function fetchLyrics(query) {
  const apiKey = global.hookrestKey || global.apikey // ambil dari global
  if (!apiKey) throw new Error('API key hookrest belum diatur di config.')

  const url = `https://hookrest.my.id/search/lirik?query=${encodeURIComponent(query)}`
  const res = await axios.get(url, { timeout: 15000 })
  return res.data
}

export default {
  help: ['lyrics <judul>', 'lirik <judul>'],
  tags: ['tools'],
  command: ['lyrics', 'lirik'],
  limit: true,

  code: async (m, { conn, args }) => {
    if (!args || args.length === 0) {
      return m.reply('Kirim perintah diikuti judul lagu, contoh:\n.lyrics tabola bale')
    }

    const query = args.join(' ').trim()
    try {
      m.reply(`> *_proses kaka @${m.sender.split('@')[0]}..._*`, m.chat, { mentions: [m.sender] })

      const data = await fetchLyrics(query)

      if (!data || data.status !== true || !data.data || !data.data.lirik) {
        return m.reply('Maaf, lirik tidak ditemukan untuk judul tersebut.')
      }

      const { title, artis, lirik } = data.data

      // Canvas setup
      const canvasWidth = 1200
      const padding = 60
      const lineHeight = 36
      const lyricsFont = `normal ${lineHeight}px Poppins, Sans`

      const measureCanvas = createCanvas(canvasWidth, 2000)
      const mctx = measureCanvas.getContext('2d')
      mctx.font = lyricsFont

      const lyricLines = []
      const paragraphs = lirik.split(/\n{1,}/g)
      for (const p of paragraphs) {
        if (!p.trim()) {
          lyricLines.push('')
          continue
        }
        lyricLines.push(...wrapText(mctx, p, canvasWidth - padding * 2))
        lyricLines.push('')
      }

      const canvasHeight = padding * 2 + lyricLines.length * lineHeight
      const canvas = createCanvas(canvasWidth, Math.max(canvasHeight, 400))
      const ctx = canvas.getContext('2d')

      // Background gradient
      const grad = ctx.createLinearGradient(0, 0, 0, canvas.height)
      grad.addColorStop(0, '#0f172a')
      grad.addColorStop(1, '#071029')
      ctx.fillStyle = grad
      ctx.fillRect(0, 0, canvas.width, canvas.height)

      // Judul
      ctx.font = 'bold 40px Poppins, Sans'
      ctx.fillStyle = '#ffffff'
      ctx.fillText(title, padding, padding)

      // Artis
      ctx.font = '24px Poppins, Sans'
      ctx.fillStyle = 'rgba(255,255,255,0.85)'
      ctx.fillText(artis, padding, padding + 50)

      // Lirik
      ctx.font = lyricsFont
      ctx.fillStyle = 'rgba(255,255,255,0.95)'
      let y = padding + 120
      for (const line of lyricLines) {
        if (line === '') {
          y += lineHeight / 1.5
          continue
        }
        ctx.fillText(line, padding, y)
        y += lineHeight
      }

      // Watermark
      const wm = 'hookrest.my.id • lyrics'
      ctx.font = '12px Poppins, Sans'
      ctx.fillStyle = 'rgba(255,255,255,0.3)'
      ctx.textAlign = 'right'
      ctx.fillText(wm, canvas.width - padding, canvas.height - 20)

      const buffer = canvas.toBuffer('image/png')

      await conn.sendMessage(
        m.chat,
        { image: buffer, caption: `${title} — ${artis}` },
        { quoted: m }
      )
    } catch (err) {
      console.error(err)
      m.reply('Terjadi kesalahan saat mengambil/merender lirik: ' + (err.message || err))
    }
  }
}

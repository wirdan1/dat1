// > Creator: Danz
// > Plugin: addplugin.js
// > Fungsi: Menambahkan file plugin dari pesan yang di-reply (mendukung .js dan .mjs)
// > Akses: Real Owner
// > Format: .addplugin namafile.js atau .addplugin namafile.mjs (reply pesan berisi kode)

const fs = require('fs');

let handler = async (m, { conn, text }) => {
  // Hanya jalan jika reply berisi kode
  if (!text) return m.reply('> ☘️ *Masukkan nama file!*\nContoh: *.addplugin namafile.js* atau *.addplugin namafile.mjs*');
  if (!text.match(/\.(js|mjs)$/)) return m.reply('> ☘️ *Nama file harus berformat .js atau .mjs*');
  if (!m.quoted || !m.quoted.text) return m.reply('> ☘️ *Balas pesan berisi kode plugin yang ingin ditambahkan!*');

  const filePath = `./plugins/${text}`;
  if (fs.existsSync(filePath)) {
    return m.reply('> ☘️ *Nama plugin sudah ada!*\nSilakan gunakan nama lain.');
  }

  try {
    const code = m.quoted.text;
    fs.writeFileSync(filePath, code);
    m.reply(`> ☘️ *Berhasil menambahkan plugin*\nNama file: *${text}*\nSilakan restart bot untuk mengaktifkan.`);
  } catch (e) {
    console.error(e);
    m.reply('> ☘️ *Gagal menyimpan file plugin!*');
  }
};

// Cukup gunakan ini agar hanya Real Owner yang bisa akses
handler.owner = true;

handler.help = ['addplugin <namafile.js|namafile.mjs> (reply kode)'];
handler.tags = ['owner'];
handler.command = ['addplugin', 'addp', 'addplug'];

module.exports = handler;
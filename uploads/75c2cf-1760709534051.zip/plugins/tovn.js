const fetch = require("node-fetch");
const { toWhatsAppVoice } = require("../lib/audioConverter");

const handler = async (m, { conn }) => {
  try {
    const q = m.quoted ? m.quoted : m;
    const mime = (q.msg || q).mimetype || "";

    if (!mime) return m.reply("> Balas atau kirim video/audio dengan perintah *.tovn*");

    // Reaksi proses
    await conn.sendMessage(m.chat, { react: { text: "🎧", key: m.key } });

    const media = await q.download();

    // Konversi ke format voice note WhatsApp
    const { audio, waveform } = await toWhatsAppVoice(media);

    // Kirim hasil voice note
    await conn.sendMessage(
      m.chat,
      {
        audio,
        mimetype: "audio/ogg; codecs=opus",
        ptt: true,
        waveform,
        fileName: "voice-note.ogg",
      },
      { quoted: m },
    );

    // Reaksi sukses
    await conn.sendMessage(m.chat, { react: { text: "✅", key: m.key } });
  } catch (err) {
    console.error(err);
    await conn.sendMessage(m.chat, { react: { text: "❌", key: m.key } });
    m.reply("> Terjadi kesalahan saat mengonversi media:\n" + err.message);
  }
};

handler.help = ["tovn"];
handler.tags = ["tools"];
handler.command = /^tovn$/i;

module.exports = handler;
import fetch from "node-fetch"

const handler = async (m, { text, command, usedPrefix }) => {
  if (!text)
    return m.reply(
      `> Masukkan nomor yang ingin dicek!\n*Contoh:* ${usedPrefix + command} 6281234567890`
    )

  const number = text.replace(/[^0-9]/g, "")
  if (!number.startsWith("62"))
    return m.reply("> Nomor harus diawali dengan *62*")

  try {
    m.reply("> Sedang memeriksa nomor...")

    const res = await fetch(`https://validk.vercel.app/api/number/validate/${number}`)
    if (!res.ok) throw new Error("Gagal menghubungi server.")
    const data = await res.json()

    // Jika respon mengandung "error"
    if (data?.error) {
      return m.reply(`> Yahh... nomor mu tidak valid bang, coba periksa lagi nomor nya.`)
    }

    // Jika valid
    if (data?.valid) {
      return m.reply(`> Wanjay... nomor mu terbukti valid, silahkan gunakan script ini bg`)
    } else {
      return m.reply(`> Yahh... nomor mu tidak valid bang, coba periksa lagi nomor nya.`)
    }
  } catch (err) {
    console.error(err)
    m.reply("> Terjadi kesalahan saat memeriksa nomor. Coba lagi nanti.")
  }
}

handler.help = ["cekvalid"]
handler.tags = ["tools"]
handler.command = /^(cekvalid)$/i
handler.limit = 5

export default handler
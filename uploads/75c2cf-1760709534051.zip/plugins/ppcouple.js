// > Creator: Danz
// > Plugin: ppcp.js

const fetch = require('node-fetch');

let handler = async (m, { conn }) => {
    try {
        const res = await fetch('https://raw.githubusercontent.com/ShirokamiRyzen/WAbot-DB/main/fitur_db/ppcp.json');
        if (!res.ok) throw new Error(`Gagal mengambil data: ${res.status}`);
        const data = await res.json();
        if (!Array.isArray(data) || data.length === 0) throw new Error('Data kosong atau tidak valid');

        const cita = data[Math.floor(Math.random() * data.length)];

        // Kirim gambar cowo
        let cowo = await (await fetch(cita.cowo)).buffer();
        await conn.sendMessage(m.chat, { image: cowo, caption: '> Cowo' }, { quoted: m });

        // Kirim gambar cewe
        let cewe = await (await fetch(cita.cewe)).buffer();
        await conn.sendMessage(m.chat, { image: cewe, caption: '> Cewe' }, { quoted: m });

    } catch (e) {
        console.error('PPCP Error:', e);
        await conn.sendMessage(m.chat, {
            text: `> Gagal mengambil gambar\n> *Error:* ${e.message || e}`
        }, { quoted: m });
    }
};

handler.help = ['ppcp'];
handler.tags = ['search'];
handler.command = /^ppcp$/i;

module.exports = handler;

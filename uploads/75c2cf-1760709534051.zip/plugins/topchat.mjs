import fs from 'fs'
import path from 'path'

const filePath = path.join('./chatCounter.json')

// Load data dari file
function loadData() {
  if (!fs.existsSync(filePath)) return {}
  try {
    return JSON.parse(fs.readFileSync(filePath))
  } catch (e) {
    return {}
  }
}

// Simpan data ke file
function saveData(data) {
  fs.writeFileSync(filePath, JSON.stringify(data, null, 2))
}

// Data utama
let chatCounter = loadData()

// Cek & reset tiap minggu
function resetIfSunday() {
  const now = new Date()
  const day = now.getDay() // Minggu = 0
  const lastReset = chatCounter._lastReset ? new Date(chatCounter._lastReset) : null

  if (!lastReset || day === 0 && lastReset.toDateString() !== now.toDateString()) {
    chatCounter = { _lastReset: now }
    saveData(chatCounter)
  }
}

let handler = async (m, { conn, participants }) => {
  resetIfSunday()

  let id = m.chat
  chatCounter[id] = chatCounter[id] || {}
  let stats = chatCounter[id]

  // Pastikan semua member grup ada walaupun belum chat
  for (let p of participants) {
    if (!stats[p.id]) stats[p.id] = 0
  }

  // Urutkan dari paling aktif
  let sorted = Object.entries(stats).sort((a, b) => b[1] - a[1])

  let teks = `📊 *Ranking Aktivitas Member Grup*\n\n`
  let mentions = []
  let i = 1
  for (let [jid, count] of sorted) {
    teks += `${i}. @${jid.split('@')[0]} = ${count} pesan\n`
    mentions.push(jid)
    i++
  }

  conn.sendMessage(m.chat, { text: teks, mentions }, { quoted: m })
}

handler.help = ['topchat']
handler.tags = ['group']
handler.command = /^topchat$/i
handler.group = true

// Middleware hitung chat
handler.before = async function (m) {
  if (!m.isGroup || !m.sender) return
  resetIfSunday()

  chatCounter[m.chat] = chatCounter[m.chat] || {}
  chatCounter[m.chat][m.sender] = (chatCounter[m.chat][m.sender] || 0) + 1

  saveData(chatCounter)
}

export default handler

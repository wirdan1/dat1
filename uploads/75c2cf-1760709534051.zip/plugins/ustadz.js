const { createCanvas, loadImage } = require('canvas')
const fetch = require('node-fetch')

let handler = async (m, { conn, text }) => {
  if (!text) throw '> Masukkan teks pertanyaan untuk ustadz.'

  try {
    const templateUrl = 'https://files.catbox.moe/mj8qgt.jpg'
    const res = await fetch(templateUrl)
    const buffer = await res.buffer()

    const baseImage = await loadImage(buffer)
    const canvas = createCanvas(baseImage.width, baseImage.height)
    const ctx = canvas.getContext('2d')

    ctx.drawImage(baseImage, 0, 0)

    ctx.fillStyle = '#000'
    ctx.textAlign = 'center'

    const x = canvas.width / 2
    const maxWidth = 700

    // Kotak putih mulai di y=190 dengan tinggi sekitar 120px
    const boxY = 190
    const boxHeight = 120

    // Fungsi untuk membungkus teks
    const wrapText = (context, text, maxWidth) => {
      const words = text.split(' ')
      let lines = []
      let line = ''
      for (let n = 0; n < words.length; n++) {
        let testLine = line + words[n] + ' '
        let testWidth = context.measureText(testLine).width
        if (testWidth > maxWidth && n > 0) {
          lines.push(line.trim())
          line = words[n] + ' '
        } else {
          line = testLine
        }
      }
      lines.push(line.trim())
      return lines
    }

    // Auto-resize font sampai muat di kotak putih
    let fontSize = 38
    let lines
    let lineHeight
    while (true) {
      ctx.font = `${fontSize}px Sans`
      lineHeight = fontSize + 12
      lines = wrapText(ctx, text, maxWidth)
      let totalHeight = lines.length * lineHeight
      if (totalHeight <= boxHeight || fontSize <= 20) break
      fontSize -= 2
    }

    // Hitung posisi Y supaya teks tepat di tengah kotak putih
    const totalTextHeight = lines.length * lineHeight
    let y = boxY + (boxHeight / 2) - (totalTextHeight / 2) + lineHeight / 2

    // Gambar teks
    lines.forEach(line => {
      ctx.fillText(line, x, y)
      y += lineHeight
    })

    await conn.sendFile(m.chat, canvas.toBuffer(), 'ustadz.jpg', '', m)

  } catch (e) {
    m.reply('❌ Terjadi kesalahan: ' + e.message)
  }
}

handler.command = /^ustadz$/i
handler.help = ['ustadz <pertanyaan>']
handler.tags = ['maker']

module.exports = handler

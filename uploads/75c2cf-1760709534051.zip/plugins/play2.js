const fetch = require('node-fetch');
const yts = require('yt-search');

let handler = async (m, { conn, text, command }) => {
  if (!text) return m.reply(`> Contoh penggunaan:\n> .${command} menepi`);

  try {
    await conn.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });

    const search = await yts(text);
    const vid = search.videos[0];

    if (!vid) {
      await conn.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
      return m.reply('> Tidak ditemukan hasil video dari pencarian.');
    }

    const res = await fetch(`https://hookrest.my.id/download/ytmp3?url=${encodeURIComponent(vid.url)}`);
    if (!res.ok) throw new Error('Gagal menghubungi API.');

    const json = await res.json();
    if (!json.status || !json.result || !json.result.download) {
      throw new Error('Gagal mengambil audio dari API.');
    }

    const { title, duration, quality, download } = json.result;

    await conn.sendMessage(m.chat, {
      audio: { url: download },
      mimetype: 'audio/mpeg',
      fileName: `${title}.mp3`,
      ptt: false
    }, { quoted: m });

    await m.reply([
      '> Hasil:',
      `> *Judul:* ${title}`,
      `> *Durasi:* ${duration}`,
      `> *Kualitas:* ${quality}kbps`
    ].join('\n'));

    await conn.sendMessage(m.chat, { react: { text: '✅', key: m.key } });

  } catch (err) {
    await conn.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
    m.reply(`> Terjadi kesalahan:\n*${err.message}*`);
  }
};

handler.help = ['play2'];
handler.tags = ['downloader'];
handler.command = /^play2$/i;
handler.limit = 5;

module.exports = handler;

import fs from 'fs';

let lp = async (m) => {
    try {
        const file = fs.readdirSync('./plugins')
        let cap = '*->* List Plugin *<-*\n';
        cap += '%list';

        m.reply(cap.replace(/%list/g, file.map((a, i) => ` *-( ${i + 1} )-*: ${a}`).join("\n")));
    } catch (e) {
        m.reply('Maaf Error Mungkin Gada File Plugins');
    };
};

lp.command = ["lp", "listplugin"];
lp.help = ["lp", "listplugin"];
lp.tags = ["owner"];
lp.owner = true;

export default lp;

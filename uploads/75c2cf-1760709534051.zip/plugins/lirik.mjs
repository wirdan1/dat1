import fs from "fs"
import path from "path"
import axios from "axios"
import { createCanvas, registerFont } from "canvas"

// === Load font lokal ===
try {
  const fontsDir = path.resolve("./fonts")
  if (fs.existsSync(path.join(fontsDir, "Poppins-Bold.ttf")))
    registerFont(path.join(fontsDir, "Poppins-Bold.ttf"), { family: "Poppins", weight: "700" })
  if (fs.existsSync(path.join(fontsDir, "Poppins-Regular.ttf")))
    registerFont(path.join(fontsDir, "Poppins-Regular.ttf"), { family: "Poppins", weight: "400" })
} catch (err) {
  console.warn("Font load warning:", err.message)
}

// === Fungsi wrap teks ===
function wrapText(ctx, text, maxWidth) {
  const words = text.split(/\s+/)
  const lines = []
  let line = ""
  for (let word of words) {
    const test = line ? line + " " + word : word
    if (ctx.measureText(test).width > maxWidth && line) {
      lines.push(line)
      line = word
    } else line = test
  }
  if (line) lines.push(line)
  return lines
}

// === Ambil lirik ===
async function fetchLyrics(query) {
  const url = `https://hookrest.my.id/search/lirikv2?title=${encodeURIComponent(query)}`
  const res = await axios.get(url, { timeout: 15000 })
  return res.data
}

const handler = async (m, { conn, args, command }) => {
  if (!args.length) return m.reply(`> Contoh penggunaan:\n> *.${command} tabola bale*`)

  const query = args.join(" ").trim()
  await m.reply(`> Sedang mencari lirik untuk: *${query}*`)

  try {
    const data = await fetchLyrics(query)
    if (!data?.result?.length) return m.reply("> Lirik tidak ditemukan.")

    const { name, artistName, plainLyrics } = data.result[0]

    // === Setting dasar ===
    const colWidth = 550
    const padding = 80
    const lineHeight = 46
    const lyricsFont = `400 30px Poppins, Sans`
    const titleFont = `700 60px Poppins, Sans`
    const artistFont = `400 32px Poppins, Sans`
    const dividerColor = "rgba(255,255,255,0.15)"

    // === Hitung semua baris lirik dulu ===
    const measureCanvas = createCanvas(colWidth, 2000)
    const ctxMeasure = measureCanvas.getContext("2d")
    ctxMeasure.font = lyricsFont

    const paragraphs = plainLyrics.split(/\n{1,}/g)
    const lyricLines = []
    for (const p of paragraphs) {
      if (!p.trim()) {
        lyricLines.push("")
        continue
      }
      lyricLines.push(...wrapText(ctxMeasure, p, colWidth - 40))
      lyricLines.push("")
    }

    // === Tentukan jumlah kolom & tinggi canvas otomatis ===
    const linesPerCol = 26
    const colCount = Math.ceil(lyricLines.length / linesPerCol)
    const canvasHeight = Math.max(1200, linesPerCol * lineHeight + padding * 2)
    const canvasWidth = colWidth * colCount + padding * 2 + (colCount - 1) * 70

    const canvas = createCanvas(canvasWidth, canvasHeight)
    const ctx = canvas.getContext("2d")

    // === Background gradasi ===
    const grad = ctx.createLinearGradient(0, 0, canvas.width, canvas.height)
    grad.addColorStop(0, "#0f2027")
    grad.addColorStop(0.5, "#203a43")
    grad.addColorStop(1, "#2c5364")
    ctx.fillStyle = grad
    ctx.fillRect(0, 0, canvas.width, canvas.height)

    // === Overlay transparan ===
    ctx.fillStyle = "rgba(0,0,0,0.3)"
    ctx.fillRect(0, 0, canvas.width, canvas.height)

    // === Header ===
    ctx.font = titleFont
    ctx.fillStyle = "#ffffff"
    ctx.fillText(name, padding, 120)

    ctx.font = artistFont
    ctx.fillStyle = "#a5b4fc"
    ctx.fillText(artistName, padding, 175)

    // === Render teks multi-kolom ===
    ctx.font = lyricsFont
    ctx.fillStyle = "rgba(255,255,255,0.95)"
    let x = padding
    let y = 260
    let col = 0

    for (const line of lyricLines) {
      if (line === "") {
        y += lineHeight / 1.5
        continue
      }

      if (y + lineHeight > canvasHeight - padding) {
        col++
        x = padding + col * (colWidth + 70)
        y = 260

        ctx.strokeStyle = dividerColor
        ctx.lineWidth = 2
        ctx.beginPath()
        ctx.moveTo(x - 35, padding + 40)
        ctx.lineTo(x - 35, canvasHeight - padding)
        ctx.stroke()
      }

      ctx.fillText(line, x, y)
      y += lineHeight
    }

    // === Watermark ===
    ctx.font = "italic 16px Poppins, Sans"
    ctx.fillStyle = "rgba(255,255,255,0.4)"
    ctx.textAlign = "right"
    ctx.fillText("hookrest.my.id • lyrics", canvas.width - padding, canvas.height - 40)

    const buffer = canvas.toBuffer("image/png")
    await conn.sendMessage(
      m.chat,
      { image: buffer, caption: `${name} — ${artistName}` },
      { quoted: m }
    )
  } catch (err) {
    console.error(err)
    m.reply(`> Terjadi kesalahan saat mengambil atau merender lirik:\n*${err.message || err}*`)
  }
}

handler.help = ["lirik"]
handler.tags = ["tools"]
handler.command = /^lirik$/i
handler.limit = 1

export default handler
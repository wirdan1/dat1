/**
 * CR Ponta Sensei
 * CH https://whatsapp.com/channel/0029VagslooA89MdSX0d1X1z
 * WEB https://codeteam.my.id
**/

import axios from "axios"
import FormData from "form-data"

let handler = async (m, { conn, usedPrefix, command }) => {
  if (!m.quoted || !/image/.test(m.quoted.mimetype || "")) {
    return m.reply(
      `> Kirim / reply gambar dengan caption:\n\n*${usedPrefix + command}*`
    )
  }

  try {
    let q = m.quoted
    let mime = q.mimetype
    let media = await q.download()

    // Buat form data
    const form = new FormData()
    form.append("file", media, { filename: "image.jpg", contentType: mime })

    // API call
    const { data } = await axios.post(
      "https://removebg.one/api/predict/v2",
      form,
      { headers: { ...form.getHeaders() } }
    )

    if (!data?.data?.cutoutUrl) {
      throw new Error("Tidak ada hasil cutout dari API")
    }

    // Kirim hasil
    await conn.sendMessage(m.chat, { image: { url: data.data.cutoutUrl }, caption: "✅ Background berhasil dihapus!" }, { quoted: m })

  } catch (e) {
    console.error(e)
    m.reply("❌ *Gagal menghapus background.*\n> " + e.message)
  }
}

handler.command = /^removebg$/i
handler.help = ["removebg"]
handler.tags = ["tools"]

export default handler
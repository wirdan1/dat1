import fetch from "node-fetch"
import FormData from "form-data"

function generateTryitApiKey(userAgent) {
  let myrandomstr = Math.round(Math.random() * 100000000000).toString()

  const myhashfunction = (function () {
    const a = []
    for (let b = 0; b < 64; b++) {
      a[b] = Math.floor(4294967296 * Math.sin((b + 1) % Math.PI))
    }

    return function (c) {
      let d = 1732584193
      let e = 4023233417
      let f = -1732584194
      let g = -4023233418
      const state = [d, e, f, g]

      let l = unescape(encodeURI(c)) + "\u0080"
      let k = l.length
      const len = --k
      let cWords = Math.floor(len / 4) + 2
      cWords = (cWords + 15) & ~15
      const h = new Array(cWords).fill(0)

      h[cWords - 1] = 8 * len
      for (let i = len; i >= 0; i--) {
        h[i >> 2] |= l.charCodeAt(i) << (8 * (i % 4))
      }

      let b = 0
      while (b < cWords) {
        let A = state[0],
          B = state[1],
          C = state[2],
          D = state[3]
        let F, G
        for (let l = 0; l < 64; l++) {
          const chunkIndex =
            b +
            ([l, 5 * l + 1, 3 * l + 5, 7 * l][Math.floor(l / 16)] & 15)
          const word = h[chunkIndex] || 0

          if (l < 16) {
            F = (B & C) | (~B & D)
            G = l
          } else if (l < 32) {
            F = (D & B) | (~D & C)
            G = (5 * l + 1) & 15
          } else if (l < 48) {
            F = B ^ C ^ D
            G = (3 * l + 5) & 15
          } else {
            F = C ^ (B | ~D)
            G = (7 * l) & 15
          }

          const rotateLeft = (val, shift) =>
            (val << shift) | (val >>> (32 - shift))
          const roundConst = a[l]
          const add = (A + F + roundConst + word) | 0
          const shiftAmount = [
            7, 12, 17, 22, 5, 9, 14, 20, 4, 11, 16, 23, 6, 10, 15, 21,
          ][4 * Math.floor(l / 16) + (l % 4)]

          const newA = D
          const newD = C
          const newC = B
          const newB = (B + rotateLeft(add, shiftAmount)) | 0

          A = newA
          B = newB
          C = newC
          D = newD
        }

        state[0] = (state[0] + A) | 0
        state[1] = (state[1] + B) | 0
        state[2] = (state[2] + C) | 0
        state[3] = (state[3] + D) | 0
        b += 16
      }

      let hex = ""
      for (let i = 0; i < 32; i++) {
        const byte = (state[Math.floor(i / 8)] >> (4 * (1 ^ i))) & 0xf
        hex += byte.toString(16)
      }
      return hex.split("").reverse().join("")
    }
  })()

  const inner = myhashfunction(userAgent + myrandomstr + "hackers_become_a_little_stinkier_every_time_they_hack")
  const middle = myhashfunction(userAgent + inner)
  const outer = myhashfunction(userAgent + middle)
  const tryitApiKey = "tryit-" + myrandomstr + "-" + outer
  return tryitApiKey
}

let handler = async (m, { conn, text, command }) => {
  // text optional: kalau mau kirim chatHistory / prompt kustom
  const promptText = text?.trim() || "hi"

  // User-Agent sesuai contoh
  const USER_AGENT =
    "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Mobile Safari/537.36"

  try {
    m.reply("_*proses kak...*_")

    // generate key
    const apiKey = generateTryitApiKey(USER_AGENT)

    // siapkan form
    const form = new FormData()
    form.append("chat_style", "gpt-chat")
    form.append("chatHistory", JSON.stringify([{ role: "user", content: promptText }]))
    form.append("model", "standard")
    form.append("hacker_is_stinky", "very_stinky")

    // request
    const res = await fetch("https://api.deepai.org/hacking_is_a_serious_crime", {
      method: "POST",
      headers: {
        "authority": "api.deepai.org",
        accept: "*/*",
        "accept-language": "id-ID,id;q=0.9,en-US;q=0.8,en;q=0.7",
        "api-key": apiKey,
        "cache-control": "no-cache",
        origin: "https://deepai.org",
        pragma: "no-cache",
        "sec-ch-ua": '"Chromium";v="137", "Not/A)Brand";v="24"',
        "sec-ch-ua-mobile": "?1",
        "sec-ch-ua-platform": '"Android"',
        "sec-fetch-dest": "empty",
        "sec-fetch-mode": "cors",
        "sec-fetch-site": "same-site",
        "user-agent": USER_AGENT,
        // Note: node-fetch will set Content-Type for FormData automatically
      },
      body: form,
    })

    const status = res.status
    const text = await res.text().catch(() => "")

    // kirim balik hasil ringkas — kalau panjang, kirim file teks
    const maxLen = 1500
    if (!text) {
      return m.reply(`> *Terjadi kesalahan:* Response kosong (status ${status})`)
    }

    if (text.length > maxLen) {
      // kirim file teks jika terlalu panjang
      const filename = `deepai-${Date.now()}.txt`
      await conn.sendMessage(m.chat, {
        document: { buffer: Buffer.from(text), filename },
        fileName: filename,
        mimetype: "text/plain",
        caption: `> *Response (file) — status ${status}*`,
      }, { quoted: m })
    } else {
      await m.reply(`> *Response (status ${status}):*\n\n${text}`)
    }
  } catch (err) {
    console.error(err)
    m.reply(`> *Terjadi kesalahan:* ${err.message}`)
  }
}

handler.command = /^deepai$/i
handler.help = ["deepai <optional prompt>"]
handler.tags = ["tools"]

export default handler
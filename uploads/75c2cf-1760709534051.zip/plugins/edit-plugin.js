// > Creator: Danz
// > Plugin: editplugin.js
// > Fungsi: Mengedit isi file plugin di folder ./plugins/ (mendukung .js dan .mjs)
// > Akses: Real Owner
// > Format: .editplugin namafile.js atau .editplugin namafile.mjs (reply pesan berisi kode baru)

const fs = require('fs');

let handler = async (m, { conn, text }) => {
  // Hanya jalan jika reply berisi kode
  if (!text) return m.reply('> ☘️ *Masukkan nama file plugin!*\nContoh: *.editplugin namafile.js* atau *.editplugin namafile.mjs*');
  if (!text.match(/\.(js|mjs)$/)) return m.reply('> ☘️ *Nama file harus berformat .js atau .mjs*');
  if (!m.quoted || !m.quoted.text) return m.reply('> ☘️ *Balas pesan berisi kode baru untuk plugin!*');

  const filePath = `./plugins/${text.toLowerCase()}`;
  if (!fs.existsSync(filePath)) {
    return m.reply('> ☘️ *File plugin tidak ditemukan!*');
  }

  try {
    const newCode = m.quoted.text;
    fs.writeFileSync(filePath, newCode);
    m.reply(`> ☘️ *Berhasil mengedit plugin*\nNama file: *${text.toLowerCase()}*\nSilakan restart bot untuk mengaktifkan perubahan.`);
  } catch (e) {
    console.error(e);
    m.reply('> ☘️ *Gagal mengedit file plugin!*');
  }
};

handler.command = ['editplugin', 'editp', 'ep', 'editplug'];
handler.help = ['editplugin <namafile.js|namafile.mjs> (reply kode baru)'];
handler.tags = ['owner'];
handler.owner = true;

module.exports = handler;

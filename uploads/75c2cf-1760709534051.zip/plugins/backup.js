const fs = require("fs");
const path = require("path");
const archiver = require("archiver");
const { tmpdir } = require("os");
const up = require("cloudku-uploader");

let handler = async (m, { conn }) => {
  const zipName = `backup_${new Date().toISOString().replace(/[:.]/g, "-")}.zip`;
  const zipPath = path.join(tmpdir(), zipName);
  const output = fs.createWriteStream(zipPath);
  const archive = archiver("zip", { zlib: { level: 9 } });

  m.reply("Sedang membuat file backup...");

  output.on("close", async () => {
    try {
      const buffer = fs.readFileSync(zipPath);
      const cloudku = await up.uploadPermanent(buffer, zipName);

      let targetChat = m.isGroup ? m.sender : m.chat;

      await conn.sendMessage(targetChat, {
        document: buffer,
        fileName: zipName,
        mimetype: "application/zip"
      });

      const caption =
        `Backup berhasil dibuat\n\n` +
        `Nama File: ${zipName}\n` +
        `Size: ${cloudku.data.size || '-'}\n` +
        `URL: ${cloudku.data.url || '-'}`;

      await conn.sendMessage(targetChat, { text: caption });

      if (m.isGroup) {
        await conn.sendMessage(m.chat, { text: "Backup berhasil dibuat dan sudah dikirim ke private chat." }, { quoted: m });
      }

      fs.unlinkSync(zipPath);
    } catch (err) {
      console.error("Backup Upload Error:", err);
      m.reply("Gagal mengupload backup.");
    }
  });

  archive.on("error", err => {
    console.error("Backup Error:", err);
    m.reply("Terjadi kesalahan saat membuat backup.");
  });

  archive.pipe(output);

  archive.glob("**/*", {
    ignore: [
      "node_modules/**",
      "tmp/**",
      "sessions/**",
      "backup/**"
    ]
  });

  archive.finalize();
};

handler.command = ["backup"];
handler.help = ["backup"];
handler.tags = ["owner"];
handler.owner = true;

module.exports = handler;

/*
* Nama fitur : tqto
* Type       : Plugin ESM
*/

let handler = async (m, { conn }) => {
  let teks = `
> *Thanks To:*
• Allah SWT
• Orang Tua
• Teman-teman
• Pengguna bot ini
• Semua pihak yang telah membantu
`
  await conn.sendMessage(m.chat, { text: teks }, { quoted: m })
}

handler.help = ['tqto']
handler.tags = ['info']
handler.command = /^tqto$/i

export default handler

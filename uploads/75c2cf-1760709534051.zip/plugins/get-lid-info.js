// > Creator: Danz
// > Plugin: get-lid-info.js

let handler = async (m, { conn, text, usedPrefix, command }) => {
  let who;

  // Cek apakah grup dan ada yang ditag atau direply
  if (m.isGroup) {
    if (m.mentionedJid && m.mentionedJid[0]) {
      who = m.mentionedJid[0];
    } else if (m.quoted) {
      who = m.quoted.sender;
    } else {
      who = m.sender;
      m.reply('> Tidak ada reply atau tag. Mengambil LID kamu sendiri.');
    }
  } else {
    who = m.sender;
  }

  if (!who) {
    return m.reply('> Penggunaan salah. Reply pesan, tag seseorang, atau gunakan di private chat.');
  }

  // Pastikan fungsi tersedia
  if (typeof global.getLidFromJid !== 'function') {
    return m.reply('> Fungsi *getLidFromJid* tidak ditemukan. Pastikan sudah ditambahkan ke global.');
  }

  try {
    let lid = await global.getLidFromJid(who, conn);
    m.reply(`> *LID Info:*\n> *ID Pengguna:* ${who}\n> *LID:* ${lid}`);
  } catch (e) {
    console.error(e);
    m.reply('> Terjadi kesalahan saat mendapatkan LID. Pastikan ID valid dan bot dalam kondisi aktif.');
  }
};

handler.help = ['getlid'];
handler.tags = ['tools'];
handler.command = /^(getlid)$/i;

module.exports = handler;

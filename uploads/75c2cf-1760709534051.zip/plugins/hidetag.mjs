let handler = async (m, { conn, text, participants }) => {
  if (!m.quoted && !text) return m.reply('Ketik pesan atau balas media yang mau dikirim.\n\nContoh: .hidetag Halo semua 👋')

  try {
    let member = participants.map(u => u.id)
    
    if (m.quoted) {
      // Kalau balas pesan (media/dokumen)
      let q = m.quoted
      let mime = (q.msg || q).mimetype || ''
      let media = await q.download?.()

      if (/image/.test(mime)) {
        await conn.sendMessage(m.chat, { 
          image: media, 
          caption: text || '', 
          mentions: member 
        }, { quoted: m })
      } else if (/video/.test(mime)) {
        await conn.sendMessage(m.chat, { 
          video: media, 
          caption: text || '', 
          mentions: member 
        }, { quoted: m })
      } else if (/audio/.test(mime)) {
        await conn.sendMessage(m.chat, { 
          audio: media, 
          mimetype: 'audio/mpeg', 
          ptt: false, 
          mentions: member 
        }, { quoted: m })
      } else {
        await conn.sendMessage(m.chat, { 
          document: media, 
          fileName: q.fileName || 'file', 
          mimetype: mime, 
          caption: text || '', 
          mentions: member 
        }, { quoted: m })
      }
    } else {
      // Kalau cuma teks biasa
      await conn.sendMessage(m.chat, { 
        text: text, 
        mentions: member 
      }, { quoted: m })
    }
  } catch (e) {
    console.error(e)
    m.reply('> Gagal mengirim hidetag!')
  }
}

handler.help = ['hidetag <teks> (bisa juga reply media)']
handler.tags = ['group']
handler.command = ['hidetag', 'h']

handler.group = true
handler.admin = true

export default handler

let handler = async (m, { conn, text, command }) => {
  if (!text) {
    return m.reply(`> *Contoh penggunaan:*\n\n.${command} https://chat.whatsapp.com/xxxxxxxxxxxxxxxx`)
  }

  let match = text.match(/chat\.whatsapp\.com\/([\w\d]+)/)
  if (!match) {
    return m.reply("> Link grup tidak valid. Pastikan format benar!")
  }

  let inviteCode = match[1]
  try {
    let res = await conn.groupAcceptInvite(inviteCode)
    m.reply(`✅ Berhasil join grup!\n\n> ID Grup: ${res}`)
  } catch (e) {
    console.error(e)
    if (e?.data === 403) {
      m.reply("⚠️ Grup butuh persetujuan admin, bot telah mengirim permintaan masuk.")
      try {
        await conn.groupRequestInvite(inviteCode, m.sender, "Permintaan join via bot")
      } catch (err) {
        console.error(err)
      }
    } else {
      m.reply("❌ Gagal masuk ke grup. Link mungkin sudah kadaluarsa atau bot diblokir.")
    }
  }
}

handler.command = /^joingc$/i
handler.help = ["joingc <link>"]
handler.tags = ["group"]

export default handler
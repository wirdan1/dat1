const more = String.fromCharCode(8206)
const readmore = more.repeat(1000) // Reduced length to avoid potential issues
const { toWhatsAppVoice } = require("../lib/audioConverter")
const fetch = require("node-fetch")
const fs = require("fs")

// Declare global variables
const rin = {
  help: ["menu"],
  command: ["menu"],
  tags: ["run"],
  code: async (m, { conn, text, isROwner, usedPrefix }) => {
    function getPluginsByTags(selectedTags = []) {
      const tagCount = {}
      const tagHelpMapping = {}
      const selectedTagsLower = selectedTags.map((tag) => tag.toLowerCase())
      const uniqueCommands = new Set() // To track unique commands

      Object.keys(global.plugins)
        .filter((name) => !global.plugins[name].disabled)
        .forEach((name) => {
          const plugin = global.plugins[name]
          const tags = Array.isArray(plugin.tags) ? plugin.tags : []
          const helps = Array.isArray(plugin.help) ? plugin.help : [plugin.help]

          tags.forEach((tag) => {
            const lower = tag.toLowerCase()
            if (selectedTags.length > 0 && !selectedTagsLower.includes(lower)) return
            if (!tagCount[tag]) {
              tagCount[tag] = 1
              tagHelpMapping[tag] = [...helps]
            } else {
              tagHelpMapping[tag].push(...helps)
            }
            helps.forEach((help) => uniqueCommands.add(help))
          })
        })

      if (Object.keys(tagCount).length === 0) {
        return {
          text: "*Tidak ada plugin ditemukan untuk tag tersebut.*",
          count: 0,
        }
      }

      const textOutput = Object.keys(tagCount)
        .map((tag) => {
          const list = tagHelpMapping[tag].map((item, i) => `> *${usedPrefix}${item}*`).join("\n")
          return `*${tag.toUpperCase()}*\n${list}`
        })
        .join("\n\n")

      return {
        text: textOutput,
        count: uniqueCommands.size,
      }
    }

    const user = {
      name: m.pushName || "User",
      number: m.sender.split("@")[0],
      limit: global.db.data.users[m.sender]?.limit || 0,
      status: isROwner ? "Pemilik Bot" : "Pengguna Biasa",
    }

    const botNumber = Array.isArray(global.owner)
      ? global.owner[0]
      : typeof global.owner === "string"
        ? global.owner
        : "6289532395263"
    const cleanBotNumber = botNumber.replace("@s.whatsapp.net", "").split("@")[0]

    const botInfo = {
      name: global.namebot || "rin-bot",
      number: cleanBotNumber,
    }

    const header =
      `*Menu ${botInfo.name}*\n\n` +
      `> Gunakan perintah berikut:\n` +
      `> *${usedPrefix}menu all* - Menampilkan semua fitur\n` +
      `> *${usedPrefix}menu list* - Daftar tag fitur\n` +
      `> *${usedPrefix}menu <tag>* - Fitur per kategori\n` +
      `> *${usedPrefix}owner* - Kontak pemilik bot\n\n`

    const botInfoSection =
      `*Info Bot:*\n` + `> Nama : *${botInfo.name}*\n` + `> Nomor Owner: *wa.me/${botInfo.number}*\n${readmore}`

    const userInfoSection =
      `*Info Anda:*\n` +
      `> Nama : *${user.name}*\n` +
      `> Nomor Owner: *wa.me/${user.number}*\n` +
      `> Limit: *${user.limit}*\n` +
      `> Status: *${user.status}*`

    const footer = `\n\n*Terima kasih telah menggunakan ${botInfo.name}*`

    let caption = ""

    if (text === "all") {
      const { text: allCommands, count } = getPluginsByTags()
      caption = `${header}${botInfoSection}\n\n${userInfoSection}\n> Total Fitur: *${count}*\n\n${allCommands}${footer}`
    } else if (text === "list") {
      const allTags = []
      Object.keys(global.plugins).forEach((name) => {
        const plugin = global.plugins[name]
        if (!plugin.disabled && plugin.tags) {
          plugin.tags.forEach((tag) => {
            if (tag && !allTags.includes(tag.toLowerCase())) {
              allTags.push(tag.toLowerCase())
            }
          })
        }
      })

      const tagsList = allTags.map((tag) => `> *${usedPrefix}menu ${tag}*`).join("\n")
      caption = `${header}${botInfoSection}\n\n${userInfoSection}\n\n*Daftar Tag:*\n${tagsList}${footer}`
    } else if (text) {
      const tags = text.split(/[,\s]+/).filter((tag) => tag.trim())
      const { text: filteredCommands, count } = getPluginsByTags(tags)
      caption = `${header}${botInfoSection}\n\n${userInfoSection}\n\n*Total Fitur: ${count}*\n\n${filteredCommands}${footer}`
    } else {
      caption =
        `${header}${botInfoSection}\n\n${userInfoSection}\n\n*Contoh penggunaan:*\n` +
        `> *${usedPrefix}menu downloader*\n> *${usedPrefix}menu tools*\n> *${usedPrefix}menu game*${footer}`
    }

    let mentionedJid = []
    try {
      mentionedJid = conn
        .parseMention(caption)
        .filter((jid) => typeof jid === "string" && jid.match(/^\d+@s\.whatsapp\.net$/))
    } catch {
      mentionedJid = []
    }

    const styledCaption = Styles(caption)

    // Kirim menu dengan thumbnail 16:9
    await conn.sendMessage(
      m.chat,
      {
        text: styledCaption,
        contextInfo: {
          ...(mentionedJid.length > 0 ? { mentionedJid } : {}),
          externalAdReply: {
            mediaType: 1,
            title: global.namebot || "Danz-bot",
            body: typeof global.owner === "string" ? global.owner : "Unknown",
            sourceUrl: global.link || "https://example.com",
            thumbnail: fs.readFileSync("./media/thumb.png"), // Thumbnail lokal
            renderLargerThumbnail: true,
          },
        },
      },
      { quoted: m },
    )

    try {
      const audioResponse = await fetch("https://files.catbox.moe/xkwufi.mp3")
      const audioBuffer = await audioResponse.buffer()
      const { audio, waveform } = await toWhatsAppVoice(audioBuffer)

      await conn.sendMessage(
        m.chat,
        {
          audio: audio,
          waveform: waveform,
          mimetype: "audio/ogg; codecs=opus",
          ptt: true,
          contextInfo: {
            externalAdReply: {
              mediaType: 1,
              title: global.namebot || "rin-bot",
              body: typeof global.owner === "string" ? global.owner : "Unknown",
              sourceUrl: global.link || "https://example.com",
              thumbnail: fs.readFileSync("./media/thumb.png"), // Thumbnail 16:9
              renderLargerThumbnail: true,
            },
          },
        },
        { quoted: m },
      )
    } catch (error) {
      console.error("Error sending audio:", error)
      await conn.sendMessage(
        m.chat,
        {
          audio: {
            url: "https://files.catbox.moe/xkwufi.mp3",
          },
          mimetype: "audio/mpeg",
          ptt: true,
          contextInfo: {
            externalAdReply: {
              mediaType: 1,
              title: global.namebot || "rin-bot",
              body: typeof global.owner === "string" ? global.owner : "Unknown",
              sourceUrl: global.link || "https://example.com",
              thumbnail: fs.readFileSync("./media/thumb.png"), // Thumbnail fallback
              renderLargerThumbnail: true,
            },
          },
        },
        { quoted: m },
      )
    }
  },
}

function Styles(text, style = 1) {
  const xStr = "abcdefghijklmnopqrstuvwxyz1234567890".split("")
  const yStr = {
    1: "ᴀʙᴄᴅᴇꜰɢʜɪᴊᴋʟᴍɴᴏᴘǫʀꜱᴛᴜᴠᴡxʏᴢ1234567890",
  }
  const replacer = []
  xStr.forEach((v, i) => replacer.push({ original: v, convert: yStr[style].charAt(i) }))

  const parts = text.split(/(wa\.me\/\d+|\*\w+\*|\n|[@\d+@s.whatsapp.net])/g)
  return parts
    .map((part) => {
      if (part.match(/wa\.me\/\d+/) || part.match(/\*\w+\*/) || part === "\n" || part.match(/[@\d+@s.whatsapp.net]/)) {
        return part
      }
      return part
        .toLowerCase()
        .split("")
        .map((v) => {
          const r = replacer.find((x) => x.original === v)
          return r ? r.convert : v
        })
        .join("")
    })
    .join("")
}

module.exports = rin
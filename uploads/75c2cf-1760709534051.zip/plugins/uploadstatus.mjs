// plugin/upsw.js
import uploadFile from '../lib/uploadFile.js'
import uploadImage from '../lib/uploadImage.js'

const mimeAudio = 'audio/mpeg'
const mimeVideo = 'video/mp4'
const mimeImage = 'image/jpeg'

export default {
  help: ['upsw <caption>'],
  tags: ['owner'],
  command: ['upsw', 'upstory', 'upstatus'],
  rowner: true,   // hanya root owner
  group: true,    // hanya bisa di grup
  limit: false,   // tanpa limit

  code: async (m, { conn, text }) => {
    let teks = text || (m.quoted && m.quoted.text) || ''
    if (!m.quoted) throw '❌ Reply/kutip media atau teks untuk diupload ke status.'

    const mtype = m.quoted.mtype
    let doc = {}

    if (mtype === 'audioMessage') {
      const link = await uploadFile(await m.quoted.download())
      doc = {
        mimetype: mimeAudio,
        ptt: true,
        audio: { url: link }
      }
    } else if (mtype === 'videoMessage') {
      const link = await uploadFile(await m.quoted.download())
      doc = {
        mimetype: mimeVideo,
        caption: teks,
        video: { url: link }
      }
    } else if (mtype === 'imageMessage') {
      const link = await uploadImage(await m.quoted.download())
      doc = {
        mimetype: mimeImage,
        caption: teks,
        image: { url: link }
      }
    } else if (mtype === 'extendedTextMessage') {
      doc = { text: teks }
    } else {
      throw '❌ Media type tidak valid!'
    }

    // ambil semua member GC buat statusJidList
    const group = await conn.groupMetadata(m.chat)
    const pp = group.participants.map(v => v.id)

    try {
      await conn.sendMessage('status@broadcast', doc, {
        backgroundColor: getRandomHexColor(),
        font: Math.floor(Math.random() * 9),
        statusJidList: pp
      })
      m.reply(`✅ Sukses upload ${mtype.replace('Message', '')} ke status`)
    } catch (e) {
      console.error('upsw error:', e)
      m.reply('❌ Gagal upload ke status: ' + e.message)
    }
  }
}

function getRandomHexColor() {
  return (
    '#' +
    Math.floor(Math.random() * 16777215)
      .toString(16)
      .padStart(6, '0')
  )
}

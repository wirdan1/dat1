import os from "os"
import { performance } from "perf_hooks"
import { createCanvas } from "canvas"

const handler = async (m, { conn }) => {
  const start = performance.now()

  const hostname = os.hostname()
  const platform = os.platform()
  const arch = os.arch()
  const release = os.release()
  const cpus = os.cpus()
  const cpuModel = cpus[0]?.model || "Unknown"
  const cpuCores = cpus.length
  const cpuSpeed = cpus[0]?.speed || 0
  const totalMem = os.totalmem()
  const freeMem = os.freemem()
  const usedMem = totalMem - freeMem
  const percentUsed = (usedMem / totalMem) * 100
  const uptimeSec = os.uptime()
  const days = Math.floor(uptimeSec / 86400)
  const hours = Math.floor((uptimeSec % 86400) / 3600)
  const minutes = Math.floor((uptimeSec % 3600) / 60)
  const seconds = Math.floor(uptimeSec % 60)
  const latency = (performance.now() - start).toFixed(2)

  const width = 900
  const height = 480
  const canvas = createCanvas(width, height)
  const ctx = canvas.getContext("2d")

  // Background gradient
  const gradient = ctx.createLinearGradient(0, 0, width, height)
  gradient.addColorStop(0, "#141414")
  gradient.addColorStop(1, "#1c1c1c")
  ctx.fillStyle = gradient
  ctx.fillRect(0, 0, width, height)

  // Header
  ctx.fillStyle = "#ffffff"
  ctx.font = "bold 34px 'Segoe UI'"
  ctx.fillText("System Monitor", 40, 60)

  ctx.strokeStyle = "#3a3a3a"
  ctx.lineWidth = 2
  ctx.beginPath()
  ctx.moveTo(40, 75)
  ctx.lineTo(width - 40, 75)
  ctx.stroke()

  // Latency
  ctx.font = "22px 'Segoe UI'"
  ctx.fillStyle = "#aaaaaa"
  ctx.fillText("Latency:", 40, 120)
  ctx.fillStyle = latency < 100 ? "#4CAF50" : latency < 300 ? "#FFC107" : "#F44336"
  ctx.fillText(`${latency} ms`, 160, 120)

  // CPU Section
  ctx.fillStyle = "#ffffff"
  ctx.font = "24px 'Segoe UI Semibold'"
  ctx.fillText("CPU", 40, 170)
  ctx.font = "18px 'Segoe UI'"
  ctx.fillStyle = "#cccccc"
  ctx.fillText(`Model: ${cpuModel}`, 40, 200)
  ctx.fillText(`Cores: ${cpuCores}`, 40, 225)
  ctx.fillText(`Speed: ${cpuSpeed} MHz`, 40, 250)

  // Memory Bar
  ctx.fillStyle = "#ffffff"
  ctx.font = "24px 'Segoe UI Semibold'"
  ctx.fillText("Memory Usage", 40, 310)
  const barWidth = 760
  const barHeight = 26
  const barX = 40
  const barY = 330
  ctx.fillStyle = "#2a2a2a"
  ctx.fillRect(barX, barY, barWidth, barHeight)
  ctx.fillStyle = "#007BFF"
  ctx.fillRect(barX, barY, (barWidth * percentUsed) / 100, barHeight)
  ctx.font = "18px 'Segoe UI'"
  ctx.fillStyle = "#e0e0e0"
  ctx.fillText(`${percentUsed.toFixed(2)}%`, barX + barWidth + 15, barY + 20)

  // OS Info
  ctx.fillStyle = "#ffffff"
  ctx.font = "24px 'Segoe UI Semibold'"
  ctx.fillText("OS Info", 40, 390)
  ctx.font = "18px 'Segoe UI'"
  ctx.fillStyle = "#cccccc"
  ctx.fillText(`${platform} (${arch}) • ${release}`, 40, 415)
  ctx.fillText(`Hostname: ${hostname}`, 40, 440)

  // Uptime
  const uptime = `${days}d ${hours}h ${minutes}m ${seconds}s`
  ctx.fillStyle = "#ffffff"
  ctx.font = "22px 'Segoe UI Semibold'"
  ctx.fillText("Uptime:", 600, 120)
  ctx.fillStyle = "#cccccc"
  ctx.font = "20px 'Segoe UI'"
  ctx.fillText(uptime, 700, 120)

  // Shadow overlay for depth
  ctx.shadowColor = "rgba(0,0,0,0.3)"
  ctx.shadowBlur = 15

  const buffer = canvas.toBuffer()

  await conn.sendMessage(m.chat, {
    image: buffer,
    caption: "*System Monitor Dashboard*",
  }, { quoted: m })
}

handler.help = ["pingg", "latency"]
handler.tags = ["info"]
handler.command = /^(pingg|latency)$/i

export default handler
import axios from "axios"
import { toWhatsAppVoice } from "../lib/audioConverter.js"

const ytmp3 = async (m, { conn, text }) => {
  try {
    if (!text || !text.includes("youtu")) {
      return m.reply(`⚠️ Masukkan link YouTube!\n\nContoh:\n.ytmp3 https://youtu.be/xxxx`)
    }

    await m.reply("_*Proses kak_ >_<*\n\n> Menghubungi server...")

    const apiUrl = `https://api.yupra.my.id/api/downloader/ytmp3?url=${encodeURIComponent(text)}`
    const resp = await axios.get(apiUrl)
    const res = resp.data

    if (!res || res.status !== 200 || !res.result) {
      return m.reply("❌ Gagal memproses permintaan.")
    }

    const data = res.result
    const caption = `*YOUTUBE MP3 DOWNLOADER*\n\n` +
      `> *Title:* ${data.title || "-"}\n` +
      `> *Duration:* ${data.duration || "-"} detik\n` +
      `> *Size:* ${data.filesize ? (data.filesize / 1024 / 1024).toFixed(2) + " MB" : "-"}\n` +
      `> *Status:* ${data.status || "-"}\n`

    await m.reply("> Mengunduh file...")

    const buffer = Buffer.from(
      (await axios.get(data.link, { responseType: "arraybuffer" })).data
    )

    if (buffer.length > 1024 * 1024 * 100) { // >100MB
      await conn.sendMessage(
        m.chat,
        {
          document: buffer,
          fileName: `${data.title}.mp3`,
          mimetype: "audio/mpeg",
          caption,
        },
        { quoted: m }
      )
    } else {
      try {
        const { audio, waveform } = await toWhatsAppVoice(buffer)
        
        await conn.sendMessage(
          m.chat,
          {
            audio: audio,
            waveform: waveform,
            fileName: `${data.title}.ogg`,
            mimetype: "audio/ogg; codecs=opus",
            caption,
          },
          { quoted: m }
        )
      } catch (conversionError) {
        console.error("Stable conversion failed, using fallback:", conversionError)
        // Fallback to original method
        await conn.sendMessage(
          m.chat,
          {
            audio: buffer,
            fileName: `${data.title}.mp3`,
            mimetype: "audio/mpeg",
            caption,
          },
          { quoted: m }
        )
      }
    }
  } catch (e) {
    console.error(e)
    m.reply("❌ Gagal memproses permintaan.\n" + e.message)
  }
}

ytmp3.command = /^ytmp3|yta$/i
ytmp3.help = ["ytmp3 <url>"]
ytmp3.tags = ["downloader"]

export default ytmp3
